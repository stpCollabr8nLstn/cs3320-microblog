# p4
References: 
http://www.1dogwoof.com/2013/09/10-tips-best-image-size-blog.html
for best size of photos

We are using 1 of our group days